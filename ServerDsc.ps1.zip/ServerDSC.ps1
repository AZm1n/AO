﻿configuration ServerDsc
{
    param
    (
        [Parameter(Mandatory)]
        [String[]]$Disks,
        [Int]$RetryCount=3,
        [Int]$RetryIntervalSec=30,
        [Int]$i=2
    )
        
  Import-DscResource -ModuleName Xstorage
    
    Node localhost
    {
     foreach($Disk in $Disks)
     {
     xWaitforDisk Disk
        {
             DiskNumber = $i
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk Disk
        {
            DiskNumber = $i
            DriveLetter = $Disks.f
        }
        $i++
     }
   
 }

    
}