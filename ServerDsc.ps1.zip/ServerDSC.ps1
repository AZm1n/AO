﻿configuration PrepareServer
{
    param
    (
        [Parameter(Mandatory)]
        [String[]]$Disks,
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xComputerManagement,CDisk,XDisk,xNetworking

    Node localhost
    {

    foreach($Disk in $Disks)

    {
            $i = 1
            xWaitforDisk Disk$i
        {
             DiskNumber = $i
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart Disk_$Disk
        {
            DiskNumber = $i
            DriveLetter = $disk
        }
        $i++
    }

    }
}