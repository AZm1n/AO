﻿configuration ServerDsc
{
    param
    (
        [Parameter(Mandatory)]
        [String[]]$Disks = $null,
        [Int]$RetryCount=3,
        [Int]$RetryIntervalSec=30,
        [Int]$i=2
    )

    
      Import-DscResource -ModuleName xComputerManagement,CDisk,XDisk,xNetworking
    
   
    
    Node localhost
    {

   
    foreach ($Disk in $Disks)
    {

         xWaitforDisk Disk
        {
             DiskNumber = $i
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart Disk
        {
            DiskNumber = $i
            DriveLetter = "$Disk"
        }
        $i++
   }

 

 }

    
}